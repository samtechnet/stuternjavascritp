var arrayList = ['Queen', 'Elizabeth', 'Of Hearts', 'Beyonce'],
    arrayList2 = ['Kevin', 'Bacon', 'Love', 'Hart', 'Costner', 'Spacey'];
 

function transformFirstAndLast(array) {
  var res = Object.create(null);
      res[array[0]] = array[array.length-1];
      console.log(res);
      return res;
}

transformFirstAndLast(arrayList);
transformFirstAndLast(arrayList2);