var obj = {
    key: 'value'
};
var output = getProperty(obj, 'key');
console.log(output);

function getProperty(obj, key) {
    return obj[key]
}