function getValue() {
    alert(document.getElementById('age').getValue);

    function isOldEnoughToDrink(age) {
        if (age >= 18) {
            return true;
        }
        else (age <= 18); {
            return false
        }
    }
}
/* write a function called "isOldEnoughToDrink". 
Given that a number, in this case an age, "isOldEnoughToDrink" return whether a person of this given is old enough to legally drink in Nigeria. */

function isOldEnoughToDrink(age) {
    if (age >= 18) {
        return true;
    }
    else (age <= 18); {
        return false
    }
}

var output = isOldEnoughToDrink(17);
console.log(output);