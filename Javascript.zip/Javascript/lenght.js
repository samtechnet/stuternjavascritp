
var output = computeAverageLengthOfWords('code', 'programs');

function computeAverageLengthOfWords(word1, word2) {
    
    let computeAverageLengthOfWords = (word1.length + word2.length) / 2
    console.log(computeAverageLengthOfWords);
    
  }